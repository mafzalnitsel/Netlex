import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../../services/api.service';
// import {environment} from '../../../environments/environment.prod';

import { environment } from '../../../environments/environment';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Lawyer } from '../../models/lawyer.model';
import { Role } from 'src/app/models/role';
import { LawyerService } from '../../services/lawyer.service';
import { menuactionspagename } from 'src/app/models/pagesnameandId';
import { AuthService } from '../../services/auth.service';
@Component({
    selector: 'app-view-user',
    templateUrl: './view-user.component.html',
    styleUrls: ['./view-user.component.scss']
})
export class ViewUserComponent implements OnInit {
    private sub: any;
    lawyer: Lawyer[];
    role: Role[];
    id: '';
    firstName = '';
    lastName = '';
    userName = '';
    email = '';
    roles = '';
    status = '';
    lawyerid = '';
    showloading = false;
    alert: { success: boolean, text: string } = { success: true, text: '' };
    profilePic: any;
    fileSource: any;
    imagePath: '';
    imgURL: string | ArrayBuffer;
    rolesValue = ['Administration', 'Advokat', 'Biträdande jurist'];
    statusValue = ['Aktiv', 'Inaktiv'];
    user: { firstName: string; lastName: string; userName: string; roles: string; email: string; status: string; lawyerid: string; roleID: string; }[];

    roleID = '';
    roleValue: any;

  lawyerAlreadyExisting: Boolean = true;

    //New for email restrictions
    validUserList = [];

    constructor(
        private router: Router,
        private route: ActivatedRoute,
        private lawyerService: LawyerService,
        private api: ApiService,
        private snackBar: MatSnackBar,
        private authService: AuthService
    ) { }

    ngOnInit(): void {
        this.checkRoleAction();
        this.sub = this.route.params.subscribe(params => {
            this.id = params.id;
            this.getUserDate();
        });
        this.getLawyer();
        this.getRole();
    }
    getLawyer(): void {
        this.lawyerService.getActiveLawyersList().subscribe(res => {
            this.lawyer = res.lawyer;
        },
            err => {
                console.log('err', err);
            }
        );
    }

    getRole(): void {
        this.api.getactiverole().subscribe(res => {
            this.role = res.doc;
            this.findRoleValue();
        },
            err => {
                console.log('err', err);
            }
        );
    }
    onChangeRole(event): void {
        // console.log("event",event)
        this.role.forEach(ele => {
            if (event == ele._id) {
                // this.roleValue = ele.useForLawyer,
                    // this.roleID = event._id,
                    this.roleID = event,
                    this.roles = ele.name
                //  console.log('this.roles',this.roles)
            }
        })
        // console.log("this.roleID",this.roleID)
        // console.log("this.roles",this.roles)
    }
    findRoleValue() {
        this.role.forEach(ele => {
            if (this.roleID == ele._id) { this.roleValue = ele.useForLawyer }
        })
    }
    getUserDate(): any {
        this.api.getUser(this.id)

            .subscribe(
                res => {
                    console.log("res",res)
                    this.firstName = res.firstName;
                    this.lastName = res.lastName;
                    this.userName = res.userName;
                    this.email = res.email;
                    this.roles = res.roles;
                    this.status = res.status;
                    this.lawyerid = res.lawyerid;
                    this.roleID = res.roleID;

                    if (res.profilePic) {
                        //  this.imgURL = environment.serviceURL + res.profilePic;
                        this.imgURL = environment.serviceURL + res.profilePic;

                    }
                },
                err => { }
            );


    }
    reset(): any {
        this.showloading = true;
        this.api.resetPassword(this.id)
            .subscribe(
                res => {
                    this.snackBar.open('Lösenordsåterställningen lyckades', 'ok');
                    this.showloading = false;
                },
                err => {
                    this.showloading = false;
                }
            );
    }
    checkAlreadyExistingLawyer(value){
        // console.log("value",value)
        this.lawyerAlreadyExisting = value;
      }
      existingLawyerHandler(event) {
        // console.log("event",event)
        // this.lawyerRequired = false;
        this.firstName = event.firstName;
        this.lastName = event.lastName;
        this.userName = event.firstName;
        this.email = event.email;
    
      }
    //New for email restrictions
    getLawyersEmailWithAvailability() {
        this.validUserList = [];
        if (this.email) {
            this.lawyerService.getLawyersEmailWithAvailability(this.email).subscribe(res => {
                // console.log('res:',res)
                this.validUserList = res.scheduleMap;
                console.log("this.validUserList",this.validUserList);

                //New for email restrictions
                if (this.validUserList.length > 0) {
                    if (this.validUserList[0] == "Error") {
                        this.showloading = false;
                        this.snackBar.open('Din e-postadress är ogiltig', 'ok');
                        return;
                    }
                }
                //------------------------------
                // else {
                    this.api.updateUser(this.user, this.id)
                    .subscribe(
                        res => {
                            this.snackBar.open('Användaren uppdaterades lyckades', 'ok');
                            this.showloading = false;
                        },
                        err => {
                            this.showloading = false;
                        }
                    );
                this.router.navigate(['/user']);
                // }
            });
        }
    }

    
    //--------------------------------------

    update(): any {
        if (this.lawyerAlreadyExisting === false) {
            this.clearLawyerField();
        }
        if (this.roleValue === true) {
            if (!this.lawyerid) {
                this.showloading = false;
                this.snackBar.open('Fyll i alla fält', 'ok');
                return;
            }
        }

        this.showloading = true;
        this.snackBar.open("Snälla vänta", '',{
            duration: 1500,
          });
          
        this.user = [{
            'firstName': this.firstName,
            'lastName': this.lastName,
            'userName': this.userName,
            'roles': this.roles,
            'email': this.email,
            'status': this.status,
            'lawyerid': this.lawyerid,
            'roleID': this.roleID,

        }]
        if (!this.firstName || !this.lastName || !this.userName || !this.email || !this.roleID || !this.status) {

            this.showloading = false;
            this.snackBar.open('Fyll i alla fält', 'ok');
            return;
        }
        this.getLawyersEmailWithAvailability();
        //old before email restrictions (28-09-2022)
        // this.api.updateUser(this.user, this.id)
        //     .subscribe(
        //         res => {
        //             this.snackBar.open('Användaren uppdaterades lyckades', 'ok');
        //             this.showloading = false;
        //         },
        //         err => {
        //             this.showloading = false;
        //         }
        //     );
        // this.router.navigate(['/user']);
    }


    onFileChange(event): any {
        if (event.target.files.length > 0) {
            this.preview(event.target.files);
            const file = event.target.files[0];
            this.fileSource = file;
        }
        // console.log("this.fileSource ",this.fileSource )
        // this.fileSource = {
        //     lastModified: '',
        //     lastModifiedDate: '',
        //     name: 'image.jpg',
        //     size: '',
        //     type: 'image/jpg',
        //     webkitRelativePath:''
        // }
    }
    clearLawyerField(): void {
        this.lawyerid = '';
    }
    changeProfile(): any {
        const formData = new FormData();
        formData.append('file', this.fileSource);
        formData.append('userId', this.id);
        this.api.uploadProfilePic(formData)
            .subscribe(res => {
                this.snackBar.open('Profilbilden har uppdaterats', 'ok');
            });
    }

    preview(files): any {
        if (files.length === 0) {
            return;
        }

        const mimeType = files[0].type;
        if (mimeType.match(/image\/*/) == null) {
            // this.message = 'Only images are supported.';
            return;
        }

        const reader = new FileReader();
        this.imagePath = files;
        reader.readAsDataURL(files[0]);
        reader.onload = (event) => {
            this.imgURL = reader.result;
        };
    }
    checkRoleAction(): any {
        let RoleID = this.authService.getroleID();
        let roleactionID = menuactionspagename.user.MAId;
        this.api.GetRoleActionByRoleIdRoleActionId(RoleID, roleactionID)
            .subscribe(
                res => {
                    if (res.menuactionslist.length == 0) {
                        this.authService.logout();
                    }

                },
                err => { }
            );
    }

}
