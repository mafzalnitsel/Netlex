import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/models/user.model';
import { AuthService } from 'src/app/services/auth.service';
import { ApiService } from 'src/app/services/api.service';
import { Router } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { LawyerService } from '../../services/lawyer.service';
import { Lawyer } from '../../models/lawyer.model';
import { Role } from 'src/app/models/role';
import { AnswerTypeModel } from '../../models/answerType.model';
import { AnswerTypeService } from '../../services/answerType.service';
import { menuactionspagename } from 'src/app/models/pagesnameandId';
@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.scss']
})
export class CreateUserComponent implements OnInit {
  lawyer: Lawyer[];
  lawyerid: string;
  selectedLawyerId: string;
  lawyerDetails = { id: '', firstName: '', lastName: '' }
  answerType: AnswerTypeModel[];
  alert: { success: boolean, text: string } = { success: true, text: '' };
  user: User = { email: '', firstName: '', lastName: '', userName: '', roles: '', _id: '', profilePic: '', status: '', lawyerid: '', roleID: '' };
  roles: string;
  showloading = false;
  userName: string;
  rolesValue = ['Administration', 'Advokat', 'Biträdande jurist'];
  userForm = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.email]),
  });

  role: Role[];
  roleId: string;
  selectedRoleId: string;
  // roleValue: any;

  lawyerAlreadyExisting: Boolean = false;
  lawyerRequired = false;
  roleRequired = false;
  //New for email restrictions
  validUserList = [];

  constructor(
    private authService: AuthService,
    private lawyerService: LawyerService,
    private api: ApiService,
    private snackBar: MatSnackBar,
    private router: Router, private answerTypeService: AnswerTypeService,
  ) { }

  ngOnInit(): void {
    this.checkRoleAction();
    this.getLawyer();
    this.getRole();
  }
  getLawyer(): void {
    this.lawyerService.getActiveLawyersList().subscribe(res => {
      this.lawyer = res.lawyer;
    },
      err => {
        console.log('err', err);
      }
    );
  }
  getRole(): void {
    this.api.getactiverole().subscribe(res => {
      this.role = res.doc;
      // console.log('this.role', this.role)
    },
      err => {
        console.log('err', err);
      }
    );
  }



  onChangeRole(event): void {
    // console.log('event', event)

    // this.role.forEach(ele => {
    //   if (event == ele._id) {
    // this.roleValue = event.useForLawyer,
    this.user.roleID = event._id;
    this.user.roles = event.name;
    // }
    // })
    
    // console.log("this.roleID", this.user.roleID)
    // console.log("this.roles", this.user.roles)
    this.roleRequired = false;
  }
  checkAlreadyExistingLawyer(value) {
    // console.log("value",value)
    this.lawyerAlreadyExisting = value;
  }
  existingLawyerHandler(event) {
    // console.log("event",event)
    this.lawyerRequired = false;
    this.user.firstName = event.firstName;
    this.user.lastName = event.lastName;
    this.user.userName = event.firstName;
    this.user.email = event.email;

  }
  //New for email restrictions
  getLawyersEmailWithAvailability() {
    this.validUserList = [];
    if (this.user.email) {
      this.lawyerService.getLawyersEmailWithAvailability(this.user.email).subscribe(res => {
        // console.log('res:',res)
        this.validUserList = res.scheduleMap;
        // console.log("this.validUserList",this.validUserList);

        //New for email restrictions
        if (this.validUserList.length > 0) {
          if (this.validUserList[0] == "Error") {
            this.showloading = false;
            this.snackBar.open('Din e-postadress är ogiltig', 'ok');
            return;
          }
        }
        //------------------------------
        // else {
        this.api.registerUser(this.user)
          .subscribe(
            res => {
              this.showloading = false;
              this.snackBar.open('Skapades framgångsrikt', 'ok');
              this.redirect();
              this.clearFields();
            },
            err => {
              this.snackBar.open('Skapad misslyckad', 'ok');
              this.showloading = false;
              console.log(err);
            }
          );
        // }
      });
    }
  }

  //--------------------------------------

  onsubmit(): void {


    if (this.lawyerAlreadyExisting === false) {
      this.lawyerRequired = false;
      this.clearLawyerField();
    }
    if (!this.user.roleID) {
      this.roleRequired = true;
    }
    if (this.lawyerAlreadyExisting === true) {
      if (!this.user.lawyerid) {
        this.lawyerRequired = true;
        this.showloading = false;
        this.snackBar.open('Fyll i alla fält', 'Ok', {
          duration: 3000,
        });
        return;
      }
    }
    if (!this.user.email || !this.user.firstName || !this.user.lastName || !this.user.roleID) {
      this.showloading = false;

      this.snackBar.open('Fyll i alla fält', 'Ok', {
        duration: 3000,
      });
      return;
    }


    this.showloading = true;
    this.snackBar.open("Snälla vänta", '', {
      duration: 1500,
    });
    this.getLawyersEmailWithAvailability();

  }
  clearFields(): void {
    this.user.firstName = '';
    this.user.lastName = '';
    this.user.email = '';
    // this.user.roles = '';
    this.user.roleID = '';

  }
  clearLawyerField(): void {
    this.user.lawyerid = '';
  }
  redirect(): void {
    this.router.navigate(['/user']);
  }
  checkRoleAction(): any {
    let RoleID = this.authService.getroleID();
    let roleactionID = menuactionspagename.user.MAId;
    this.api.GetRoleActionByRoleIdRoleActionId(RoleID, roleactionID)
      .subscribe(
        res => {
          if (res.menuactionslist.length == 0) {
            this.authService.logout();
          }

        },
        err => { }
      );
  }
}
